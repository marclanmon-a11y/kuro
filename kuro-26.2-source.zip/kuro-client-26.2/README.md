# Kuro Client (Fabric, Minecraft 26.2)
Right Shift in-game opens the GUI (Fullbright toggle).

Build: push to GitHub -> Actions -> "build" -> download artifact "kuro-jar" -> unzip -> put the .jar in your instance's mods folder.
