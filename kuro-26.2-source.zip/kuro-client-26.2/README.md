# Kuro Client (Fabric, Minecraft 26.2)

Press **Right Shift** in a world to open the menu.

- Left-click a module's switch to turn it on or off (right-click anywhere on the row also toggles it).
- Left-click a row that has an arrow to open its settings; drag sliders to change numbers.
- Type to search, scroll with the mouse wheel, Esc to close.
- Your toggles and settings are saved to `config/kuro.properties`.

## Modules (28)

**Render:** Fullbright, Zoom, FOV
**HUD:** Watermark, Module List, Coordinates, Nether Coords, Direction, FPS, Speed Meter, Clock, Memory, Health, Hunger, XP Level, Rotation, Chunk Coords, Players Online, Nearby Entities
**Movement:** Auto Sprint, Auto Walk, Always Sneak, Auto Jump
**Player:** Anti AFK, Auto Respawn, Auto Mine, Auto Use, Panic

## Adding a module

Create a `Module` subclass (see `PlayerModules.java` for short examples), give it a name, description and category,
add settings with `add(Setting.number(...))` or `add(Setting.bool(...))`, override `onTick`, and register it in the
matching `register(...)` method. It shows up in the menu automatically.

## Building

`gradle build` with JDK 25 (the GitHub Action in this repo does this for you). The jar lands in `build/libs/`.
