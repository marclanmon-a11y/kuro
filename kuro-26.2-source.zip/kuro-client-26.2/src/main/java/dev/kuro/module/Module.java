package dev.kuro.module;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public abstract class Module {
	public final String name;
	public final String description;
	public final Category category;
	public final List<Setting> settings = new ArrayList<>();
	private boolean enabled;

	protected Module(String name, String description, Category category) {
		this.name = name;
		this.description = description;
		this.category = category;
	}

	protected Setting add(Setting setting) {
		settings.add(setting);
		return setting;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean value) {
		if (value == enabled) {
			return;
		}
		enabled = value;
		Minecraft mc = Minecraft.getInstance();
		if (value) {
			onEnable(mc);
		} else {
			onDisable(mc);
		}
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	/** Used when loading the config: sets the flag without running onEnable (there may be no world yet). */
	void restoreEnabled(boolean value) {
		enabled = value;
	}

	public void onEnable(Minecraft mc) {
	}

	public void onDisable(Minecraft mc) {
	}

	/** Runs every client tick while enabled and a world is loaded. */
	public void onTick(Minecraft mc) {
	}

	/** One line of text for the HUD (HUD modules). Return null to draw nothing. */
	public String hudText(Minecraft mc) {
		return null;
	}

	public int hudColor() {
		return 0xFFFFFFFF;
	}

	/** Custom HUD drawing, for modules that need more than one line of text. */
	public void renderHud(GuiGraphicsExtractor graphics, Minecraft mc) {
	}
}
