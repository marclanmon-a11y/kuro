package dev.kuro.module;

import java.util.Locale;

/** A single option on a module: either an on/off switch or a number slider. */
public class Setting {
	public final String name;
	public final boolean isBool;
	public final double min;
	public final double max;
	public final double step;
	private double value;

	private Setting(String name, boolean isBool, double def, double min, double max, double step) {
		this.name = name;
		this.isBool = isBool;
		this.min = min;
		this.max = max;
		this.step = step;
		this.value = def;
	}

	public static Setting bool(String name, boolean def) {
		return new Setting(name, true, def ? 1 : 0, 0, 1, 1);
	}

	public static Setting number(String name, double def, double min, double max, double step) {
		return new Setting(name, false, def, min, max, step);
	}

	public boolean getBool() {
		return value >= 0.5;
	}

	public double getDouble() {
		return value;
	}

	public int getInt() {
		return (int) Math.round(value);
	}

	public void setValue(double v) {
		if (isBool) {
			value = v >= 0.5 ? 1 : 0;
			return;
		}
		double snapped = Math.round((v - min) / step) * step + min;
		value = Math.max(min, Math.min(max, snapped));
	}

	public void toggle() {
		value = getBool() ? 0 : 1;
	}

	public String display() {
		if (isBool) {
			return getBool() ? "ON" : "OFF";
		}
		return step >= 1 ? String.valueOf(getInt()) : String.format(Locale.ROOT, "%.2f", value);
	}
}
