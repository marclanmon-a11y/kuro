package dev.kuro.module;

import dev.kuro.gui.HudRenderer;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

final class HudModules {
	private static final int ACCENT = 0xFFA78BFA;
	private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");

	private HudModules() {
	}

	static void register(List<Module> out) {
		out.add(new Line("Watermark", "Show the Kuro Client name.", ACCENT, mc -> "Kuro Client"));
		out.add(new ArrayListHud());
		out.add(new Line("Coordinates", "Show your XYZ position.", 0xFFFFFFFF, mc -> {
			LocalPlayer p = mc.player;
			return String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ());
		}));
		out.add(new Line("Nether Coords", "Show the matching Nether coordinates.", 0xFFFCA5A5, mc -> {
			LocalPlayer p = mc.player;
			return String.format(Locale.ROOT, "Nether: %d / %d", (int) Math.floor(p.getX() / 8.0), (int) Math.floor(p.getZ() / 8.0));
		}));
		out.add(new Line("Direction", "Show which way you are facing.", 0xFFFFFFFF,
				mc -> "Facing: " + mc.player.getDirection().toString()));
		out.add(new Line("FPS", "Show your frames per second.", 0xFF86EFAC, mc -> "FPS: " + HudRenderer.fps));
		out.add(new SpeedHud());
		out.add(new Line("Clock", "Show the current time.", 0xFFFFFFFF, mc -> LocalTime.now().format(CLOCK)));
		out.add(new Line("Memory", "Show Java memory use.", 0xFFFFFFFF, mc -> {
			Runtime rt = Runtime.getRuntime();
			long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
			long max = rt.maxMemory() / 1048576L;
			return "Mem: " + used + " / " + max + " MB";
		}));
		out.add(new Line("Health", "Show your health.", 0xFFFCA5A5,
				mc -> String.format(Locale.ROOT, "HP: %.1f", mc.player.getHealth())));
		out.add(new Line("Hunger", "Show your food level.", 0xFFFDBA74,
				mc -> "Food: " + mc.player.getFoodData().getFoodLevel()));
		out.add(new Line("XP Level", "Show your experience level.", 0xFF86EFAC,
				mc -> "Level: " + mc.player.experienceLevel));
		out.add(new Line("Rotation", "Show your yaw and pitch.", 0xFFFFFFFF, mc -> String.format(Locale.ROOT, "Yaw/Pitch: %.0f / %.0f",
				Mth.wrapDegrees(mc.player.getYRot()), mc.player.getXRot())));
		out.add(new Line("Chunk Coords", "Show the chunk you are standing in.", 0xFFFFFFFF, mc -> {
			int cx = ((int) Math.floor(mc.player.getX())) >> 4;
			int cz = ((int) Math.floor(mc.player.getZ())) >> 4;
			return "Chunk: " + cx + " / " + cz;
		}));
		out.add(new Line("Players Online", "Show how many players are on the server.", 0xFFFFFFFF, mc -> {
			if (mc.getConnection() == null) {
				return null;
			}
			return "Online: " + mc.getConnection().getOnlinePlayers().size();
		}));
		out.add(new NearbyHud());
	}

	/** A HUD module that shows one line of text. */
	static final class Line extends Module {
		private final int color;
		private final Function<Minecraft, String> text;

		Line(String name, String description, int color, Function<Minecraft, String> text) {
			super(name, description, Category.HUD);
			this.color = color;
			this.text = text;
		}

		@Override
		public String hudText(Minecraft mc) {
			if (mc.player == null) {
				return null;
			}
			return text.apply(mc);
		}

		@Override
		public int hudColor() {
			return color;
		}
	}

	static final class SpeedHud extends Module {
		private double lastX;
		private double lastZ;
		private double speed;

		SpeedHud() {
			super("Speed Meter", "Show how fast you are moving in blocks per second.", Category.HUD);
		}

		@Override
		public void onTick(Minecraft mc) {
			double x = mc.player.getX();
			double z = mc.player.getZ();
			double dx = x - lastX;
			double dz = z - lastZ;
			speed = Math.sqrt(dx * dx + dz * dz) * 20.0;
			lastX = x;
			lastZ = z;
		}

		@Override
		public String hudText(Minecraft mc) {
			return String.format(Locale.ROOT, "Speed: %.1f b/s", speed);
		}
	}

	static final class NearbyHud extends Module {
		private int count;
		private int timer;

		NearbyHud() {
			super("Nearby Entities", "Count living things within 32 blocks.", Category.HUD);
		}

		@Override
		public void onTick(Minecraft mc) {
			if (timer-- > 0) {
				return;
			}
			timer = 10;
			count = Math.max(0, mc.level.getEntitiesOfClass(LivingEntity.class,
					mc.player.getBoundingBox().inflate(32.0)).size() - 1);
		}

		@Override
		public String hudText(Minecraft mc) {
			return "Nearby: " + count;
		}
	}

	/** Draws the list of enabled modules down the right-hand side of the screen. */
	static final class ArrayListHud extends Module {
		ArrayListHud() {
			super("Module List", "List your enabled modules on the right side.", Category.HUD);
		}

		@Override
		public void renderHud(GuiGraphicsExtractor graphics, Minecraft mc) {
			List<String> names = new ArrayList<>();
			Collection<Module> all = ModuleManager.MODULES;
			for (Module m : all) {
				if (m.isEnabled() && m.category != Category.HUD) {
					names.add(m.name);
				}
			}
			names.sort((a, b) -> Integer.compare(mc.font.width(b), mc.font.width(a)));
			int y = 4;
			int right = graphics.guiWidth() - 4;
			for (String n : names) {
				int w = mc.font.width(n);
				graphics.fill(right - w - 5, y - 1, right + 2, y + mc.font.lineHeight + 1, 0x90101018);
				graphics.fill(right + 2, y - 1, right + 4, y + mc.font.lineHeight + 1, ACCENT);
				graphics.text(mc.font, n, right - w, y, ACCENT);
				y += mc.font.lineHeight + 3;
			}
		}
	}
}
