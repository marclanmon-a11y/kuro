package dev.kuro.module;

import java.util.List;
import net.minecraft.client.Minecraft;

final class MovementModules {
	private MovementModules() {
	}

	static void register(List<Module> out) {
		out.add(new Module("Auto Sprint", "Always sprint while you move.", Category.MOVEMENT) {
			@Override
			public void onTick(Minecraft mc) {
				mc.options.keySprint.setDown(true);
			}

			@Override
			public void onDisable(Minecraft mc) {
				mc.options.keySprint.setDown(false);
			}
		});

		out.add(new Module("Auto Walk", "Keep walking forward.", Category.MOVEMENT) {
			@Override
			public void onTick(Minecraft mc) {
				mc.options.keyUp.setDown(true);
			}

			@Override
			public void onDisable(Minecraft mc) {
				mc.options.keyUp.setDown(false);
			}
		});

		out.add(new Module("Always Sneak", "Hold sneak automatically.", Category.MOVEMENT) {
			@Override
			public void onTick(Minecraft mc) {
				mc.options.keyShift.setDown(true);
			}

			@Override
			public void onDisable(Minecraft mc) {
				mc.options.keyShift.setDown(false);
			}
		});

		out.add(new Module("Auto Jump", "Jump up blocks automatically (vanilla option).", Category.MOVEMENT) {
			@Override
			public void onTick(Minecraft mc) {
				mc.options.autoJump().set(true);
			}

			@Override
			public void onDisable(Minecraft mc) {
				mc.options.autoJump().set(false);
			}
		});
	}
}
