package dev.kuro.module;

import java.util.List;
import net.minecraft.client.Minecraft;

final class PlayerModules {
	private PlayerModules() {
	}

	static void register(List<Module> out) {
		out.add(new Module("Anti AFK", "Jump now and then so you are not kicked for idling.", Category.PLAYER) {
			private final Setting interval = add(Setting.number("Interval (s)", 30, 5, 120, 5));
			private int ticks;
			private boolean jumping;

			@Override
			public void onTick(Minecraft mc) {
				if (jumping) {
					mc.options.keyJump.setDown(false);
					jumping = false;
					ticks = 0;
					return;
				}
				if (++ticks >= interval.getInt() * 20) {
					mc.options.keyJump.setDown(true);
					jumping = true;
				}
			}

			@Override
			public void onDisable(Minecraft mc) {
				mc.options.keyJump.setDown(false);
				ticks = 0;
				jumping = false;
			}
		});

		out.add(new Module("Auto Respawn", "Respawn the moment you die.", Category.PLAYER) {
			@Override
			public void onTick(Minecraft mc) {
				if (mc.player.isDeadOrDying()) {
					mc.player.respawn();
				}
			}
		});

		out.add(new Module("Auto Mine", "Hold the attack button down.", Category.PLAYER) {
			@Override
			public void onTick(Minecraft mc) {
				mc.options.keyAttack.setDown(true);
			}

			@Override
			public void onDisable(Minecraft mc) {
				mc.options.keyAttack.setDown(false);
			}
		});

		out.add(new Module("Auto Use", "Hold the use button down.", Category.PLAYER) {
			@Override
			public void onTick(Minecraft mc) {
				mc.options.keyUse.setDown(true);
			}

			@Override
			public void onDisable(Minecraft mc) {
				mc.options.keyUse.setDown(false);
			}
		});

		out.add(new Module("Panic", "Turn every module off at once.", Category.PLAYER) {
			@Override
			public void onEnable(Minecraft mc) {
				for (Module m : ModuleManager.MODULES) {
					if (m != this) {
						m.setEnabled(false);
					}
				}
				setEnabled(false);
			}
		});
	}
}
