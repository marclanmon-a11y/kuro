package dev.kuro.module;

public enum Category {
	RENDER("Render"),
	HUD("HUD"),
	MOVEMENT("Movement"),
	PLAYER("Player");

	public final String label;

	Category(String label) {
		this.label = label;
	}
}
