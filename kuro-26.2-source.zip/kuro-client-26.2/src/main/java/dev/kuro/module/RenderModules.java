package dev.kuro.module;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

final class RenderModules {
	private RenderModules() {
	}

	static void register(List<Module> out) {
		out.add(new Fullbright());
		out.add(new FovModule("Zoom", "Narrow your field of view to look far away.", 30, 30, 70));
		out.add(new FovModule("FOV", "Use a custom field of view.", 100, 30, 110));
	}

	static final class Fullbright extends Module {
		private boolean applied;

		Fullbright() {
			super("Fullbright", "See in the dark with a permanent night vision effect.", Category.RENDER);
		}

		@Override
		public void onTick(Minecraft mc) {
			LocalPlayer player = mc.player;
			if (player == null) {
				applied = false;
				return;
			}
			MobEffectInstance current = player.getEffect(MobEffects.NIGHT_VISION);
			if (current == null || !current.isInfiniteDuration()) {
				player.addEffect(new MobEffectInstance(
						MobEffects.NIGHT_VISION, MobEffectInstance.INFINITE_DURATION, 0, false, false, false));
			}
			applied = true;
		}

		@Override
		public void onDisable(Minecraft mc) {
			if (applied && mc.player != null) {
				mc.player.removeEffect(MobEffects.NIGHT_VISION);
			}
			applied = false;
		}
	}

	static final class FovModule extends Module {
		private final Setting value;
		private int saved = -1;

		FovModule(String name, String description, int def, int min, int max) {
			super(name, description, Category.RENDER);
			value = add(Setting.number("FOV", def, min, max, 1));
		}

		@Override
		public void onTick(Minecraft mc) {
			if (saved < 0) {
				saved = mc.options.fov().get();
			}
			mc.options.fov().set(value.getInt());
		}

		@Override
		public void onDisable(Minecraft mc) {
			if (saved >= 0) {
				mc.options.fov().set(saved);
			}
			saved = -1;
		}
	}

}
