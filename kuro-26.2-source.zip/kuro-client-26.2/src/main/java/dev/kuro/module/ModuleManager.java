package dev.kuro.module;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

public final class ModuleManager {
	public static final List<Module> MODULES = new ArrayList<>();

	private ModuleManager() {
	}

	public static void init() {
		RenderModules.register(MODULES);
		HudModules.register(MODULES);
		MovementModules.register(MODULES);
		PlayerModules.register(MODULES);
		load();
	}

	public static void tick(Minecraft mc) {
		if (mc.player == null || mc.level == null) {
			return;
		}
		for (Module m : MODULES) {
			if (!m.isEnabled()) {
				continue;
			}
			try {
				m.onTick(mc);
			} catch (Throwable t) {
				System.err.println("[Kuro] " + m.name + " crashed and was turned off: " + t);
				m.setEnabled(false);
			}
		}
	}

	public static List<Module> inCategory(Category category) {
		List<Module> list = new ArrayList<>();
		for (Module m : MODULES) {
			if (category == null || m.category == category) {
				list.add(m);
			}
		}
		return list;
	}

	public static int enabledCount() {
		int n = 0;
		for (Module m : MODULES) {
			if (m.isEnabled()) {
				n++;
			}
		}
		return n;
	}

	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("kuro.properties");
	}

	public static void save() {
		Properties p = new Properties();
		for (Module m : MODULES) {
			p.setProperty(m.name + ".enabled", String.valueOf(m.isEnabled()));
			for (Setting s : m.settings) {
				p.setProperty(m.name + "." + s.name, String.valueOf(s.getDouble()));
			}
		}
		try (OutputStream out = Files.newOutputStream(configPath())) {
			p.store(out, "Kuro Client config");
		} catch (IOException e) {
			System.err.println("[Kuro] could not save config: " + e);
		}
	}

	private static void load() {
		Path path = configPath();
		if (!Files.exists(path)) {
			return;
		}
		Properties p = new Properties();
		try (InputStream in = Files.newInputStream(path)) {
			p.load(in);
		} catch (IOException e) {
			System.err.println("[Kuro] could not read config: " + e);
			return;
		}
		for (Module m : MODULES) {
			m.restoreEnabled(Boolean.parseBoolean(p.getProperty(m.name + ".enabled", "false")));
			for (Setting s : m.settings) {
				String raw = p.getProperty(m.name + "." + s.name);
				if (raw == null) {
					continue;
				}
				try {
					s.setValue(Double.parseDouble(raw));
				} catch (NumberFormatException ignored) {
				}
			}
		}
	}
}
