package dev.kuro;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class KuroScreen extends Screen {
	public KuroScreen() {
		super(Component.literal("Kuro Client"));
	}

	private static Component fullbrightLabel() {
		return Component.literal("Fullbright: " + (KuroClient.fullbright ? "ON" : "OFF"));
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int cy = this.height / 2;

		this.addRenderableWidget(Button.builder(fullbrightLabel(), button -> {
			KuroClient.fullbright = !KuroClient.fullbright;
			button.setMessage(fullbrightLabel());
		}).bounds(cx - 75, cy - 10, 150, 20).build());

		this.addRenderableWidget(Button.builder(Component.literal("Close"), button -> this.onClose())
				.bounds(cx - 75, cy + 16, 150, 20).build());
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
