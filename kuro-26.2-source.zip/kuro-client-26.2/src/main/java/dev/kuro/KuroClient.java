package dev.kuro;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import org.lwjgl.glfw.GLFW;

public class KuroClient implements ClientModInitializer {
	public static boolean fullbright = false;

	private boolean rightShiftWasDown = false;
	private boolean nightVisionApplied = false;

	@Override
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(this::tick);
	}

	private void tick(Minecraft mc) {
		// Right Shift opens the GUI (only when no other screen, e.g. chat, is open)
		long window = GLFW.glfwGetCurrentContext();
		if (window != 0L) {
			boolean down = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
			if (down && !rightShiftWasDown && mc.screen == null && mc.player != null) {
				mc.setScreen(new KuroScreen());
			}
			rightShiftWasDown = down;
		}

		applyFullbright(mc);
	}

	private void applyFullbright(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (player == null) {
			nightVisionApplied = false;
			return;
		}

		if (fullbright) {
			MobEffectInstance current = player.getEffect(MobEffects.NIGHT_VISION);
			if (current == null || !current.isInfiniteDuration()) {
				player.addEffect(new MobEffectInstance(
						MobEffects.NIGHT_VISION, MobEffectInstance.INFINITE_DURATION, 0, false, false, false));
			}
			nightVisionApplied = true;
		} else if (nightVisionApplied) {
			player.removeEffect(MobEffects.NIGHT_VISION);
			nightVisionApplied = false;
		}
	}
}
