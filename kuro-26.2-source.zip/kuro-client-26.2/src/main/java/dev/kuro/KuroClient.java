package dev.kuro;

import dev.kuro.gui.HudRenderer;
import dev.kuro.gui.KuroScreen;
import dev.kuro.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class KuroClient implements ClientModInitializer {
	private boolean rightShiftWasDown = false;

	@Override
	public void onInitializeClient() {
		ModuleManager.init();
		ClientTickEvents.END_CLIENT_TICK.register(this::tick);
		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("kuro", "hud"),
				(graphics, deltaTracker) -> HudRenderer.render(graphics));
	}

	private void tick(Minecraft mc) {
		// Right Shift opens the menu (only when no other screen, e.g. chat, is open)
		long window = GLFW.glfwGetCurrentContext();
		if (window != 0L) {
			boolean down = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
			if (down && !rightShiftWasDown && mc.gui.screen() == null && mc.player != null) {
				mc.gui.setScreen(new KuroScreen());
			}
			rightShiftWasDown = down;
		}

		ModuleManager.tick(mc);
	}
}
