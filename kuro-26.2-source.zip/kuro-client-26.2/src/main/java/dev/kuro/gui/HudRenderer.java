package dev.kuro.gui;

import dev.kuro.module.Category;
import dev.kuro.module.Module;
import dev.kuro.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Draws the on-screen info lines of the HUD modules every frame. */
public final class HudRenderer {
	public static int fps;
	private static int frames;
	private static long windowStart = System.currentTimeMillis();

	private HudRenderer() {
	}

	public static void render(GuiGraphicsExtractor graphics) {
		Minecraft mc = Minecraft.getInstance();

		// Count frames so the FPS module has something to show
		frames++;
		long now = System.currentTimeMillis();
		if (now - windowStart >= 1000L) {
			fps = frames;
			frames = 0;
			windowStart = now;
		}

		if (mc.player == null || mc.level == null) {
			return;
		}

		int y = 4;
		for (Module m : ModuleManager.MODULES) {
			if (!m.isEnabled() || m.category != Category.HUD) {
				continue;
			}
			String line = m.hudText(mc);
			if (line != null) {
				graphics.text(mc.font, line, 4, y, m.hudColor());
				y += mc.font.lineHeight + 2;
			}
		}

		for (Module m : ModuleManager.MODULES) {
			if (m.isEnabled()) {
				m.renderHud(graphics, mc);
			}
		}
	}
}
