package dev.kuro.gui;

import dev.kuro.module.Category;
import dev.kuro.module.Module;
import dev.kuro.module.ModuleManager;
import dev.kuro.module.Setting;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** The Kuro Client menu: category tabs, a search box, module switches and per-module settings. */
public class KuroScreen extends Screen {
	// Colours (ARGB)
	private static final int DIM = 0x99000000;
	private static final int BORDER = 0xFF4C3A8A;
	private static final int PANEL = 0xF0101016;
	private static final int SIDEBAR = 0xFF0B0B10;
	private static final int LINE = 0xFF24242E;
	private static final int FIELD = 0xFF1A1A24;
	private static final int ROW = 0xFF171720;
	private static final int ROW_HOVER = 0xFF1E1E2A;
	private static final int ROW_ON = 0xFF221C3A;
	private static final int SETTING_BG = 0xFF13131B;
	private static final int ACCENT = 0xFFA78BFA;
	private static final int ACCENT_DIM = 0xFF3B2F6B;
	private static final int TEXT = 0xFFE5E7EB;
	private static final int SUB = 0xFF8B8FA3;
	private static final int SWITCH_OFF = 0xFF3A3A48;
	private static final int KNOB = 0xFFFFFFFF;

	private static final int SIDEBAR_W = 92;
	private static final int ROW_H = 28;

	private record Hit(int x1, int y1, int x2, int y2, Runnable left, Runnable right) {
		boolean contains(double x, double y) {
			return x >= x1 && x < x2 && y >= y1 && y < y2;
		}
	}

	private record SliderHit(Setting setting, int x1, int x2, int y1, int y2) {
	}

	private final List<Hit> hits = new ArrayList<>();
	private final List<SliderHit> sliders = new ArrayList<>();

	private Category selected = null; // null means "All"
	private Module expanded = null;
	private SliderHit dragging = null;
	private String query = "";
	private int scroll = 0;
	private int maxScroll = 0;

	public KuroScreen() {
		super(Component.literal("Kuro Client"));
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void removed() {
		ModuleManager.save();
		super.removed();
	}

	// ---------------------------------------------------------------- drawing helpers

	private static void rounded(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int color) {
		g.fill(x1 + 2, y1, x2 - 2, y2, color);
		g.fill(x1, y1 + 2, x2, y2 - 2, color);
		g.fill(x1 + 1, y1 + 1, x2 - 1, y2 - 1, color);
	}

	private static void drawSwitch(GuiGraphicsExtractor g, int x, int y, boolean on) {
		rounded(g, x, y, x + 24, y + 12, on ? ACCENT : SWITCH_OFF);
		int kx = on ? x + 14 : x + 2;
		rounded(g, kx, y + 2, kx + 8, y + 10, KNOB);
	}

	private String fit(String s, int maxWidth) {
		if (this.font.width(s) <= maxWidth) {
			return s;
		}
		while (s.length() > 1 && this.font.width(s + "...") > maxWidth) {
			s = s.substring(0, s.length() - 1);
		}
		return s + "...";
	}

	// ---------------------------------------------------------------- rendering

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		hits.clear();
		sliders.clear();

		int pw = Math.min(480, this.width - 16);
		int ph = Math.min(300, this.height - 16);
		int px = (this.width - pw) / 2;
		int py = (this.height - ph) / 2;

		g.fill(0, 0, this.width, this.height, DIM);
		rounded(g, px - 1, py - 1, px + pw + 1, py + ph + 1, BORDER);
		rounded(g, px, py, px + pw, py + ph, PANEL);

		// Header
		g.text(this.font, "KURO", px + 12, py + 11, ACCENT);
		g.text(this.font, "CLIENT", px + 12 + this.font.width("KURO "), py + 11, SUB);
		g.fill(px + 2, py + 31, px + pw - 2, py + 32, LINE);

		int sx2 = px + pw - 10;
		int sx1 = sx2 - 140;
		rounded(g, sx1, py + 8, sx2, py + 24, FIELD);
		boolean blink = (System.currentTimeMillis() / 500L) % 2L == 0L;
		if (query.isEmpty()) {
			g.text(this.font, "Search modules...", sx1 + 6, py + 12, SUB);
		} else {
			g.text(this.font, fit(query, 124) + (blink ? "_" : ""), sx1 + 6, py + 12, TEXT);
		}

		// Sidebar (category tabs)
		g.fill(px, py + 32, px + SIDEBAR_W, py + ph - 2, SIDEBAR);
		Category[] cats = Category.values();
		for (int i = 0; i <= cats.length; i++) {
			final Category cat = i == 0 ? null : cats[i - 1];
			String label = cat == null ? "All" : cat.label;
			int ty = py + 40 + i * 24;
			boolean isSel = cat == selected;
			boolean hover = mouseX >= px + 6 && mouseX < px + SIDEBAR_W - 6 && mouseY >= ty && mouseY < ty + 20;
			if (isSel) {
				rounded(g, px + 6, ty, px + SIDEBAR_W - 6, ty + 20, ACCENT_DIM);
				g.fill(px + 6, ty + 4, px + 8, ty + 16, ACCENT);
			} else if (hover) {
				rounded(g, px + 6, ty, px + SIDEBAR_W - 6, ty + 20, FIELD);
			}
			g.text(this.font, label, px + 16, ty + 6, isSel ? TEXT : SUB);
			hits.add(new Hit(px + 6, ty, px + SIDEBAR_W - 6, ty + 20, () -> {
				selected = cat;
				scroll = 0;
			}, null));
		}
		g.text(this.font, ModuleManager.enabledCount() + " active", px + 14, py + ph - 16, SUB);

		// Module list
		int cx1 = px + SIDEBAR_W + 8;
		int cx2 = px + pw - 10;
		int cy1 = py + 38;
		int cy2 = py + ph - 10;

		List<Module> visible = new ArrayList<>();
		String q = query.toLowerCase(Locale.ROOT);
		for (Module m : ModuleManager.inCategory(selected)) {
			if (q.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(q)) {
				visible.add(m);
			}
		}

		if (visible.isEmpty()) {
			g.centeredText(this.font, "No modules found", (cx1 + cx2) / 2, (cy1 + cy2) / 2, SUB);
		}

		int y = cy1 - scroll;
		int total = 0;
		for (Module m : visible) {
			final Module mod = m;
			boolean showRow = y >= cy1 && y + ROW_H <= cy2;
			if (showRow) {
				boolean hover = mouseX >= cx1 && mouseX < cx2 && mouseY >= y && mouseY < y + ROW_H - 2;
				rounded(g, cx1, y, cx2, y + ROW_H - 2, m.isEnabled() ? ROW_ON : (hover ? ROW_HOVER : ROW));
				if (m.isEnabled()) {
					g.fill(cx1, y + 5, cx1 + 2, y + ROW_H - 7, ACCENT);
				}
				g.text(this.font, m.name, cx1 + 9, y + 5, TEXT);
				g.text(this.font, fit(m.description, cx2 - cx1 - 70), cx1 + 9, y + 16, SUB);

				int swx = cx2 - 34;
				int swy = y + (ROW_H - 2 - 12) / 2;
				drawSwitch(g, swx, swy, m.isEnabled());
				if (!m.settings.isEmpty()) {
					g.text(this.font, expanded == m ? "v" : ">", swx - 12, y + 9, SUB);
				}

				hits.add(new Hit(swx - 14, y, cx2, y + ROW_H - 2, mod::toggle, mod::toggle));
				hits.add(new Hit(cx1, y, cx2, y + ROW_H - 2, () -> {
					if (mod.settings.isEmpty()) {
						mod.toggle();
					} else {
						expanded = expanded == mod ? null : mod;
					}
				}, mod::toggle));
			}
			y += ROW_H;
			total += ROW_H;

			if (expanded == m) {
				for (Setting s : m.settings) {
					int sh = s.isBool ? 18 : 25;
					if (y >= cy1 && y + sh <= cy2) {
						rounded(g, cx1 + 6, y, cx2 - 6, y + sh - 2, SETTING_BG);
						g.text(this.font, s.name, cx1 + 14, y + (s.isBool ? 5 : 3), TEXT);
						if (s.isBool) {
							drawSwitch(g, cx2 - 6 - 32, y + 2, s.getBool());
							hits.add(new Hit(cx1 + 6, y, cx2 - 6, y + sh - 2, s::toggle, s::toggle));
						} else {
							String value = s.display();
							g.text(this.font, value, cx2 - 14 - this.font.width(value), y + 3, ACCENT);
							int tx1 = cx1 + 14;
							int tx2 = cx2 - 14;
							int ty = y + 15;
							double ratio = (s.getDouble() - s.min) / (s.max - s.min);
							int fillX = tx1 + (int) Math.round(ratio * (tx2 - tx1));
							g.fill(tx1, ty, tx2, ty + 4, SWITCH_OFF);
							g.fill(tx1, ty, fillX, ty + 4, ACCENT);
							rounded(g, fillX - 3, ty - 2, fillX + 3, ty + 6, KNOB);
							sliders.add(new SliderHit(s, tx1, tx2, y + 10, y + sh - 2));
						}
					}
					y += sh;
					total += sh;
				}
				y += 3;
				total += 3;
			}
		}

		maxScroll = Math.max(0, total - (cy2 - cy1));
		scroll = Math.max(0, Math.min(scroll, maxScroll));

		// Scroll bar
		if (maxScroll > 0) {
			int trackH = cy2 - cy1;
			int barH = Math.max(16, trackH * trackH / (trackH + maxScroll));
			int barY = cy1 + (int) ((long) (trackH - barH) * scroll / maxScroll);
			g.fill(cx2 + 3, barY, cx2 + 5, barY + barH, ACCENT_DIM);
		}
	}

	// ---------------------------------------------------------------- input

	private void updateSlider(SliderHit hit, double mouseX) {
		double ratio = (mouseX - hit.x1()) / (double) (hit.x2() - hit.x1());
		ratio = Math.max(0.0, Math.min(1.0, ratio));
		Setting s = hit.setting();
		s.setValue(s.min + ratio * (s.max - s.min));
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		double mx = event.x();
		double my = event.y();
		int button = event.button();

		if (button == 0) {
			for (SliderHit hit : sliders) {
				if (mx >= hit.x1() - 4 && mx <= hit.x2() + 4 && my >= hit.y1() && my < hit.y2()) {
					dragging = hit;
					updateSlider(hit, mx);
					return true;
				}
			}
		}

		for (Hit hit : hits) {
			if (hit.contains(mx, my)) {
				Runnable action = button == 0 ? hit.left() : (button == 1 ? hit.right() : null);
				if (action != null) {
					action.run();
				}
				return true;
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
		if (dragging != null) {
			updateSlider(dragging, event.x());
			return true;
		}
		return super.mouseDragged(event, dragX, dragY);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		dragging = null;
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		scroll = Math.max(0, Math.min(maxScroll, scroll - (int) Math.round(scrollY * 18.0)));
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		if (event.key() == GLFW.GLFW_KEY_BACKSPACE) {
			if (!query.isEmpty()) {
				query = query.substring(0, query.length() - 1);
				scroll = 0;
			}
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	public boolean charTyped(CharacterEvent event) {
		String typed = event.codepointAsString();
		if (!typed.isEmpty() && typed.codePointAt(0) >= 32 && query.length() < 24) {
			query += typed;
			scroll = 0;
		}
		return true;
	}
}
